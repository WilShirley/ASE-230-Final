<?php
function loadData($filePath) {
    if (!file_exists($filePath)) {
        return [];
    }
    $json = file_get_contents($filePath);
    return json_decode($json, true);
}

function saveData($filePath, $data) {
    file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT));
}


function deleteEvent($filePath, $id) {
    $events = loadData($filePath);
    $filtered = array_filter($events, fn($e) => $e["id"] != $id);
    saveData($filePath, array_values($filtered));
}

function updateEvent($filePath, $id, $newData) {
    $events = loadData($filePath);
    foreach ($events as &$event) {
        if ($event["id"] == $id) {
            $event = array_merge($event, $newData);
            break;
        }
    }
    saveData($filePath, $events);
}

function authenticate($username, $password) {
    $users = loadData(__DIR__ . "/users.json");
    foreach ($users as $user) {
        if ($user["username"] === $username && $user["password"] === $password) {
            return true;
        }
    }
    return false;
}

function requireLogin() {
    session_start();
    if (!isset($_SESSION["logged_in"]) || $_SESSION["logged_in"] !== true) {
        header("Location: login.php");
        exit;
    }
}


?>