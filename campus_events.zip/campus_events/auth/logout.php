<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';

Auth::logout();

session_start(); // in case session was destroyed, we want flash
$_SESSION['flash'] = [
    'type' => 'info',
    'msg'  => 'You have been logged out.'
];

header("Location: " . BASE_URL . "index.php");
exit();
