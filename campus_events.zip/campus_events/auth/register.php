<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/Repositories/UserRepository.php';

$userRepo = new UserRepository();
$errors   = [];
$name     = '';
$email    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($name === '') {
        $errors[] = "Name is required.";
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required.";
    }
    if ($password === '') {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long.";
    }
    if ($password !== $confirm) {
        $errors[] = "Password and confirmation do not match.";
    }

    if (empty($errors)) {
        $existing = $userRepo->getByEmail($email);
        if ($existing) {
            $errors[] = "An account with that email already exists.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $userId = $userRepo->create([
                'name'          => $name,
                'email'         => $email,
                'password_hash' => $hash,
                'role'          => 'user'
            ]);

            $user = $userRepo->getById($userId);
            Auth::login($user);

            $_SESSION['flash'] = [
                'type' => 'success',
                'msg'  => 'Account created, you are now logged in.'
            ];

            header("Location: " . BASE_URL . "user/my-events.php");
            exit();
        }
    }
}

$pageTitle = "Sign Up";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4">Create an Account</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3" novalidate>
    <div class="col-12">
        <label for="name" class="form-label">Full name</label>
        <input
            type="text"
            id="name"
            name="name"
            class="form-control"
            value="<?= e($name) ?>"
            required
        >
    </div>

    <div class="col-12">
        <label for="email" class="form-label">Email</label>
        <input
            type="email"
            id="email"
            name="email"
            class="form-control"
            value="<?= e($email) ?>"
            required
        >
    </div>

    <div class="col-md-6">
        <label for="password" class="form-label">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            class="form-control"
            required
        >
    </div>

    <div class="col-md-6">
        <label for="confirm" class="form-label">Confirm password</label>
        <input
            type="password"
            id="confirm"
            name="confirm"
            class="form-control"
            required
        >
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Create account</button>
        <a href="<?= BASE_URL ?>auth/login.php" class="btn btn-link">Already have an account? Log in</a>
    </div>
</form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
