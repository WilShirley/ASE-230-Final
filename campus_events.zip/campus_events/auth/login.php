<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/Repositories/UserRepository.php';

$userRepo = new UserRepository();
$errors   = [];
$email    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required.";
    }
    if ($password === '') {
        $errors[] = "Password is required.";
    }

    if (empty($errors)) {
        $user = $userRepo->getByEmail($email);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors[] = "Invalid email or password.";
        } else {
            Auth::login($user);

            $_SESSION['flash'] = [
                'type' => 'success',
                'msg'  => 'Welcome back, ' . $user['name'] . '!'
            ];

            if ($user['role'] === 'admin') {
                header("Location: " . BASE_URL . "admin/index.php");
            } else {
                header("Location: " . BASE_URL . "user/my-events.php");
            }
            exit();
        }
    }
}

$pageTitle = "Login";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4">Log In</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3" novalidate>
    <div class="col-12">
        <label for="email" class="form-label">Email</label>
        <input
            type="email"
            id="email"
            name="email"
            class="form-control"
            value="<?= e($email) ?>"
            required
        >
    </div>

    <div class="col-12">
        <label for="password" class="form-label">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            class="form-control"
            required
        >
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Log in</button>
        <a href="<?= BASE_URL ?>auth/register.php" class="btn btn-link">Need an account? Sign up</a>
    </div>
</form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
