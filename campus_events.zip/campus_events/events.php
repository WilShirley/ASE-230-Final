<?php
$pageTitle = "Campus Events – Browse";
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/lib/Repositories/EventRepository.php';

$eventRepo = new EventRepository();
$events = $eventRepo->getAll();
?>

<h1 class="mb-4">Browse All Events</h1>

<?php if (empty($events)): ?>
    <p>No events found.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Location</th>
                <th>Category</th>
                <th>Organizer</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($events as $event): ?>
                <tr>
                    <td>
                        <a href="<?= BASE_URL ?>event.php?id=<?= (int)$event['event_id'] ?>">
                            <?= e($event['title']) ?>
                        </a>
                    </td>
                    <td><?= e($event['date']) ?></td>
                    <td><?= e($event['location']) ?></td>
                    <td><?= e($event['category_name']) ?></td>
                    <td><?= e($event['organizer_name']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
