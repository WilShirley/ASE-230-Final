<?php
require_once __DIR__ . '/Database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

class Auth {

    public static function login($user) {
        $_SESSION['user'] = [
            'user_id' => $user['user_id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ];
    }

    public static function logout() {
        unset($_SESSION['user']);
        session_destroy();
    }

    public static function user() {
        return $_SESSION['user'] ?? null;
    }

    public static function userId() {
        return $_SESSION['user']['user_id'] ?? null;
    }

    public static function isLoggedIn() {
        return isset($_SESSION['user']);
    }

    public static function isAdmin() {
        return self::isLoggedIn() && $_SESSION['user']['role'] === 'admin';
    }

    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header("Location: " . BASE_URL . "auth/login.php");
            exit();
        }
    }

    public static function requireAdmin() {
        if (!self::isAdmin()) {
            http_response_code(403);
            echo "Forbidden: Admins only";
            exit();
        }
    }
}
