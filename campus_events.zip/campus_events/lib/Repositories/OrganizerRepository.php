<?php
require_once "BaseRepository.php";

class OrganizerRepository extends BaseRepository {

    public function getAll() {
        return $this->pdo->query("SELECT * FROM organizers ORDER BY name")->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM organizers WHERE organizer_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->pdo->prepare("INSERT INTO organizers (name, email, phone) VALUES (?, ?, ?)");
        $stmt->execute([$data['name'], $data['email'], $data['phone']]);
    }

    public function update($id, $data) {
        $stmt = $this->pdo->prepare("UPDATE organizers SET name=?, email=?, phone=? WHERE organizer_id=?");
        $stmt->execute([$data['name'], $data['email'], $data['phone'], $id]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM organizers WHERE organizer_id = ?");
        $stmt->execute([$id]);
    }
}
