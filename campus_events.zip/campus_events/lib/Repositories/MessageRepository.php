<?php
require_once "BaseRepository.php";

class MessageRepository extends BaseRepository {

    public function getAll() {
        return $this->pdo->query("
            SELECT m.*, a.username AS admin_name
            FROM contact_messages m
            LEFT JOIN admins a ON m.admin_id = a.admin_id
            ORDER BY date_sent DESC
        ")->fetchAll();
    }

    public function create($data) {
        $stmt = $this->pdo->prepare("
            INSERT INTO contact_messages (name, email, subject, message_body, date_sent, admin_id)
            VALUES (?, ?, ?, ?, NOW(), ?)
        ");
        $stmt->execute([
            $data['name'], 
            $data['email'], 
            $data['subject'], 
            $data['message_body'], 
            $data['admin_id'] ?? null
        ]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM contact_messages WHERE message_id = ?");
        $stmt->execute([$id]);
    }
}
