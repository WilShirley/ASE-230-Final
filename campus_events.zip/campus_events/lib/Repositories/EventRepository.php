<?php
require_once "BaseRepository.php";

class EventRepository extends BaseRepository {

    public function getAll() {
        $sql = "
            SELECT e.*,
                   c.name AS category_name,
                   o.name AS organizer_name,
                   u.name AS owner_name
            FROM events e
            JOIN categories c ON e.category_id = c.category_id
            JOIN organizers o ON e.organizer_id = o.organizer_id
            JOIN users u ON e.user_id = u.user_id
            ORDER BY e.date ASC
        ";
        return $this->pdo->query($sql)->fetchAll();
    }

    public function getUpcoming($limit = 5) {
        $sql = "
            SELECT e.*,
                   c.name AS category_name,
                   o.name AS organizer_name,
                   u.name AS owner_name
            FROM events e
            JOIN categories c ON e.category_id = c.category_id
            JOIN organizers o ON e.organizer_id = o.organizer_id
            JOIN users u ON e.user_id = u.user_id
            WHERE e.date >= CURDATE()
            ORDER BY e.date ASC
            LIMIT :limit
        ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $sql = "
            SELECT e.*,
                   c.name AS category_name,
                   o.name AS organizer_name,
                   u.name AS owner_name
            FROM events e
            JOIN categories c ON e.category_id = c.category_id
            JOIN organizers o ON e.organizer_id = o.organizer_id
            JOIN users u ON e.user_id = u.user_id
            WHERE e.event_id = ?
            LIMIT 1
        ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function getByUser($userId) {
        $sql = "
            SELECT e.*,
                   c.name AS category_name,
                   o.name AS organizer_name
            FROM events e
            JOIN categories c ON e.category_id = c.category_id
            JOIN organizers o ON e.organizer_id = o.organizer_id
            WHERE e.user_id = ?
            ORDER BY e.date ASC
        ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    public function create($data) {
        $stmt = $this->pdo->prepare("
            INSERT INTO events (title, date, location, description, organizer_id, category_id, admin_id, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['title'],
            $data['date'],
            $data['location'],
            $data['description'],
            $data['organizer_id'],
            $data['category_id'],
            $data['admin_id'],
            $data['user_id']
        ]);
        return $this->pdo->lastInsertId();
    }

    public function update($id, $data) {
        $stmt = $this->pdo->prepare("
            UPDATE events
            SET title = ?, date = ?, location = ?, description = ?, organizer_id = ?, category_id = ?
            WHERE event_id = ?
        ");
        $stmt->execute([
            $data['title'],
            $data['date'],
            $data['location'],
            $data['description'],
            $data['organizer_id'],
            $data['category_id'],
            $id
        ]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM events WHERE event_id = ?");
        $stmt->execute([$id]);
    }
}
