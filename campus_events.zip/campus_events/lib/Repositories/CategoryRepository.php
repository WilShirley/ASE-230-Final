<?php
require_once "BaseRepository.php";

class CategoryRepository extends BaseRepository {

    public function getAll() {
        return $this->pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM categories WHERE category_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $stmt = $this->pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
        $stmt->execute([$data['name'], $data['description']]);
    }

    public function update($id, $data) {
        $stmt = $this->pdo->prepare("UPDATE categories SET name=?, description=? WHERE category_id=?");
        $stmt->execute([$data['name'], $data['description'], $id]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM categories WHERE category_id = ?");
        $stmt->execute([$id]);
    }
}
