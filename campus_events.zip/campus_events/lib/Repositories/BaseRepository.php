<?php
require_once __DIR__ . '/../Database.php';

class BaseRepository {
    protected $pdo;

    public function __construct() {
        $this->pdo = Database::getConnection();
    }
}
