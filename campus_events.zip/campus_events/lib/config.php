<?php
// CONFIG FILE
// Update user/password as needed for your XAMPP setup.

define('DB_HOST', 'localhost');
define('DB_NAME', 'campus_events');
define('DB_USER', 'root');
define('DB_PASS', ''); // usually empty on XAMPP

// Base URL if needed (adjust the folder name)
define('BASE_URL', '/campus_events');
