<?php
require_once __DIR__ . '/lib/Repositories/EventRepository.php';
$pageTitle = "Event Details";
require_once __DIR__ . '/partials/header.php';

$eventRepo = new EventRepository();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$event = $id > 0 ? $eventRepo->getById($id) : null;
?>

<?php if (!$event): ?>
    <h1 class="mb-4">Event not found</h1>
    <p>The event you requested does not exist.</p>
<?php else: ?>
    <h1 class="mb-3"><?= e($event['title']) ?></h1>

    <p class="text-muted">
        <?= e($event['date']) ?> &middot; <?= e($event['location']) ?>
    </p>

    <p>
        <strong>Category:</strong> <?= e($event['category_name']) ?><br>
        <strong>Organizer:</strong> <?= e($event['organizer_name']) ?><br>
        <strong>Posted by:</strong> <?= e($event['owner_name']) ?>
    </p>

    <hr>

    <p><?= nl2br(e($event['description'])) ?></p>

    <p class="mt-4">
        <a href="<?= BASE_URL ?>events.php" class="btn btn-outline-secondary">Back to all events</a>
    </p>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
