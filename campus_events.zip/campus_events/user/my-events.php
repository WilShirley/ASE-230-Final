<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/Repositories/EventRepository.php';

Auth::requireLogin();

$eventRepo = new EventRepository();
$events    = $eventRepo->getByUser(Auth::userId());

$pageTitle = "My Events";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4">My Events</h1>

<p class="mb-3">
    <a href="<?= BASE_URL ?>user/event-create.php" class="btn btn-primary btn-sm">Create New Event</a>
</p>

<?php if (empty($events)): ?>
    <p>You have not created any events yet.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Location</th>
                <th>Category</th>
                <th>Organizer</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($events as $event): ?>
                <tr>
                    <td>
                        <a href="<?= BASE_URL ?>event.php?id=<?= (int)$event['event_id'] ?>">
                            <?= e($event['title']) ?>
                        </a>
                    </td>
                    <td><?= e($event['date']) ?></td>
                    <td><?= e($event['location']) ?></td>
                    <td><?= e($event['category_name']) ?></td>
                    <td><?= e($event['organizer_name']) ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>user/event-edit.php?id=<?= (int)$event['event_id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <a href="<?= BASE_URL ?>user/event-delete.php?id=<?= (int)$event['event_id'] ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
