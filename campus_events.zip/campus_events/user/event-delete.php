<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/Repositories/EventRepository.php';

Auth::requireLogin();

$eventRepo = new EventRepository();

$id    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$event = $id > 0 ? $eventRepo->getById($id) : null;

if (!$event) {
    http_response_code(404);
    die("Event not found.");
}

if ($event['user_id'] != Auth::userId() && !Auth::isAdmin()) {
    http_response_code(403);
    die("You are not allowed to delete this event.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        $eventRepo->delete($id);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Event deleted.'
        ];
    }

    header("Location: " . BASE_URL . "user/my-events.php");
    exit();
}

$pageTitle = "Delete Event";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4 text-danger">Delete Event</h1>

<p>Are you sure you want to delete the event <strong><?= e($event['title']) ?></strong> scheduled for <?= e($event['date']) ?>?</p>

<form method="post">
    <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes, delete it</button>
    <a href="<?= BASE_URL ?>user/my-events.php" class="btn btn-secondary">Cancel</a>
</form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
