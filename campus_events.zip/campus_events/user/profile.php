<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';

Auth::requireLogin();

$pageTitle = "My Profile";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4">My Profile</h1>
<p>Name: <?= e(Auth::user()['name']) ?></p>
<p>Email: <?= e(Auth::user()['email']) ?></p>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
