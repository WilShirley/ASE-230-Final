<?php
$pageTitle = "Campus Events – Home";
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/lib/Repositories/EventRepository.php';

$eventRepo = new EventRepository();
$upcomingEvents = $eventRepo->getUpcoming(5);
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="mb-3">Campus Events Bulletin Board</h1>
        <p class="lead">
            See what is happening on campus, browse upcoming events, and log in to post your own.
        </p>
    </div>
</div>

<h2 class="h4 mb-3">Upcoming Events</h2>

<?php if (empty($upcomingEvents)): ?>
    <p>No upcoming events yet. Check back soon.</p>
<?php else: ?>
    <div class="row">
        <?php foreach ($upcomingEvents as $event): ?>
            <div class="col-md-6 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?= e($event['title']) ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted">
                            <?= e($event['date']) ?> &middot; <?= e($event['location']) ?>
                        </h6>
                        <p class="card-text small mb-1">
                            Category: <?= e($event['category_name']) ?><br>
                            Organizer: <?= e($event['organizer_name']) ?>
                        </p>
                        <p class="card-text">
                            <?= nl2br(e(mb_strimwidth($event['description'], 0, 160, '...'))) ?>
                        </p>
                        <a href="<?= BASE_URL ?>event.php?id=<?= (int)$event['event_id'] ?>" class="btn btn-sm btn-primary">
                            View details
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<p class="mt-4">
    <a href="<?= BASE_URL ?>events.php" class="btn btn-outline-secondary">View all events</a>
</p>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
