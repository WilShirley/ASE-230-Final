<?php
require_once __DIR__ . '/lib/Repositories/MessageRepository.php';

$pageTitle = "Contact Campus Events Admin";
require_once __DIR__ . '/partials/header.php';

$messageRepo = new MessageRepository();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $body    = trim($_POST['message'] ?? '');

    if ($name === '') {
        $errors[] = "Name is required.";
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required.";
    }
    if ($subject === '') {
        $errors[] = "Subject is required.";
    }
    if ($body === '') {
        $errors[] = "Message text is required.";
    }

    if (empty($errors)) {
        $messageRepo->create([
            'name'         => $name,
            'email'        => $email,
            'subject'      => $subject,
            'message_body' => $body,
            'admin_id'     => null
        ]);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Thank you for your message! An administrator will review it soon.'
        ];

        header("Location: " . BASE_URL . "contact.php");
        exit();
    }
}
?>

<h1 class="mb-4">Contact the Campus Events Team</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $e): ?>
                <li><?= e($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3">
    <div class="col-md-6">
        <label for="name" class="form-label">Your name</label>
        <input type="text" id="name" name="name" class="form-control"
               value="<?= e($_POST['name'] ?? '') ?>">
    </div>

    <div class="col-md-6">
        <label for="email" class="form-label">Your email</label>
        <input type="email" id="email" name="email" class="form-control"
               value="<?= e($_POST['email'] ?? '') ?>">
    </div>

    <div class="col-12">
        <label for="subject" class="form-label">Subject</label>
        <input type="text" id="subject" name="subject" class="form-control"
               value="<?= e($_POST['subject'] ?? '') ?>">
    </div>

    <div class="col-12">
        <label for="message" class="form-label">Message</label>
        <textarea id="message" name="message" rows="5" class="form-control"><?= e($_POST['message'] ?? '') ?></textarea>
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Send message</button>
    </div>
</form>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
