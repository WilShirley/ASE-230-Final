    </div> <!-- /.container -->
</main>

<footer class="bg-dark text-light mt-4 py-3">
    <div class="container text-center small">
        &copy; <?= date('Y') ?> Campus Events Bulletin Board &middot; Built with PHP, MySQL &amp; Bootstrap 5
    </div>
</footer>

<!-- Bootstrap JS bundle (with Popper) -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"
></script>

<!-- Your custom scripts if needed -->
<script src="<?= BASE_URL ?>assets/js/site.js"></script>

</body>
</html>
