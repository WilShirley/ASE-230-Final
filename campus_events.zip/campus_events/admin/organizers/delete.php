php
require_once __DIR__ . '....libconfig.php';
require_once __DIR__ . '....libAuth.php';
require_once __DIR__ . '....libhelpers.php';
require_once __DIR__ . '....libRepositoriesOrganizerRepository.php';

AuthrequireAdmin();

$organizerRepo = new OrganizerRepository();

$id  = isset($_GET['id'])  (int)$_GET['id']  0;
$org = $id  0  $organizerRepo-getById($id)  null;

if (!$org) {
    http_response_code(404);
    die(Organizer not found.);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['confirm'] === 'yes') {
        $organizerRepo-delete($id);

        $_SESSION['flash'] = [
            'type' = 'success',
            'msg'  = 'Organizer deleted.'
        ];
    }

    header(Location  . BASE_URL . adminorganizersindex.php);
    exit();
}

$pageTitle = Admin – Delete Organizer;
require_once __DIR__ . '....partialsheader.php';


h1 class=mb-4 text-dangerDelete Organizerh1

pAre you sure you want to delete the organizer strong= e($org['name']) strongp

form method=post
    button type=submit name=confirm value=yes class=btn btn-dangerYes, deletebutton
    a href== BASE_URL adminorganizersindex.php class=btn btn-secondaryCancela
form

php require_once __DIR__ . '....partialsfooter.php'; 
