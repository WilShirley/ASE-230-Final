<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/OrganizerRepository.php';

Auth::requireAdmin();

$organizerRepo = new OrganizerRepository();
$errors        = [];
$data          = [
    'name'  => '',
    'email' => '',
    'phone' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['name']  = trim($_POST['name'] ?? '');
    $data['email'] = trim($_POST['email'] ?? '');
    $data['phone'] = trim($_POST['phone'] ?? '');

    if ($data['name'] === '') {
        $errors[] = "Name is required.";
    }

    if (empty($errors)) {
        $organizerRepo->create($data);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Organizer created successfully.'
        ];

        header("Location: " . BASE_URL . "admin/organizers/index.php");
        exit();
    }
}

$pageTitle = "Admin – Create Organizer";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Create Organizer</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3">
    <div class="col-12">
        <label for="name" class="form-label">Name</label>
        <input type="text" id="name" name="name" class="form-control"
               value="<?= e($data['name']) ?>" required>
    </div>

    <div class="col-md-6">
        <label for="email" class="form-label">Email (optional)</label>
        <input type="email" id="email" name="email" class="form-control"
               value="<?= e($data['email']) ?>">
    </div>

    <div class="col-md-6">
        <label for="phone" class="form-label">Phone (optional)</label>
        <input type="text" id="phone" name="phone" class="form-control"
               value="<?= e($data['phone']) ?>">
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Save Organizer</button>
        <a href="<?= BASE_URL ?>admin/organizers/index.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
