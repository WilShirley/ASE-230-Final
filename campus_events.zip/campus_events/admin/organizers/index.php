<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/OrganizerRepository.php';

Auth::requireAdmin();

$organizerRepo = new OrganizerRepository();
$organizers    = $organizerRepo->getAll();

$pageTitle = "Admin – Organizers";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Manage Organizers</h1>

<p class="mb-3">
    <a href="<?= BASE_URL ?>admin/organizers/create.php" class="btn btn-primary btn-sm">Create New Organizer</a>
</p>

<?php if (empty($organizers)): ?>
    <p>No organizers found.</p>
<?php else: ?>
    <table class="table table-striped align-middle">
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th style="width: 160px;">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($organizers as $org): ?>
            <tr>
                <td><?= e($org['name']) ?></td>
                <td><?= e($org['email']) ?></td>
                <td><?= e($org['phone']) ?></td>
                <td>
                    <a href="<?= BASE_URL ?>admin/organizers/edit.php?id=<?= (int)$org['organizer_id'] ?>"
                       class="btn btn-sm btn-outline-secondary">Edit</a>
                    <a href="<?= BASE_URL ?>admin/organizers/delete.php?id=<?= (int)$org['organizer_id'] ?>"
                       class="btn btn-sm btn-outline-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
