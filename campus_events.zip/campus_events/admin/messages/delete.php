<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/MessageRepository.php';

Auth::requireAdmin();

$messageRepo = new MessageRepository();

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$msgs = $messageRepo->getAll();
$message = null;

foreach ($msgs as $m) {
    if ((int)$m['message_id'] === $id) {
        $message = $m;
        break;
    }
}

if (!$message) {
    http_response_code(404);
    die("Message not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['confirm'] === 'yes') {
        $messageRepo->delete($id);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Message deleted.'
        ];
    }

    header("Location: " . BASE_URL . "admin/messages/index.php");
    exit();
}

$pageTitle = "Admin – Delete Message";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4 text-danger">Delete Message</h1>

<p>Are you sure you want to delete this message from <strong><?= e($message['name']) ?></strong> (<?= e($message['email']) ?>)?</p>

<p><strong>Subject:</strong> <?= e($message['subject']) ?></p>
<p><?= nl2br(e($message['message_body'])) ?></p>

<form method="post">
    <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes, delete</button>
    <a href="<?= BASE_URL ?>admin/messages/index.php" class="btn btn-secondary">Cancel</a>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
