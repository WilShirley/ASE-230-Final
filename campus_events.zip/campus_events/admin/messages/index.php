<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/MessageRepository.php';

Auth::requireAdmin();

$messageRepo = new MessageRepository();
$messages    = $messageRepo->getAll();

$pageTitle = "Admin – Contact Messages";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Contact Messages</h1>

<?php if (empty($messages)): ?>
    <p>No messages found.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
            <tr>
                <th>Received</th>
                <th>From</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th style="width: 120px;">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($messages as $msg): ?>
                <tr>
                    <td><?= e($msg['date_sent']) ?></td>
                    <td><?= e($msg['name']) ?></td>
                    <td><?= e($msg['email']) ?></td>
                    <td><?= e($msg['subject']) ?></td>
                    <td><?= nl2br(e($msg['message_body'])) ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>admin/messages/delete.php?id=<?= (int)$msg['message_id'] ?>"
                           class="btn btn-sm btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
