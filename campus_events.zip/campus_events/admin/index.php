<?php
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/Auth.php';
require_once __DIR__ . '/../lib/helpers.php';

Auth::requireAdmin();

$pageTitle = "Admin Dashboard";
require_once __DIR__ . '/../partials/header.php';
?>

<h1 class="mb-4">Admin Dashboard</h1>

<p class="mb-4">
    Use this area to manage all events, categories, organizers, and contact messages.
</p>

<div class="row g-3">
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">Events</h5>
                <p class="card-text">View, edit, and delete all events in the system.</p>
                <a href="<?= BASE_URL ?>admin/events/index.php" class="btn btn-primary btn-sm">Manage Events</a>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">Categories</h5>
                <p class="card-text">Manage event categories.</p>
                <a href="<?= BASE_URL ?>admin/categories/index.php" class="btn btn-primary btn-sm">Manage Categories</a>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">Organizers</h5>
                <p class="card-text">Manage event organizers.</p>
                <a href="<?= BASE_URL ?>admin/organizers/index.php" class="btn btn-primary btn-sm">Manage Organizers</a>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">Contact Messages</h5>
                <p class="card-text">Review and delete messages sent from the contact form.</p>
                <a href="<?= BASE_URL ?>admin/messages/index.php" class="btn btn-primary btn-sm">View Messages</a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
