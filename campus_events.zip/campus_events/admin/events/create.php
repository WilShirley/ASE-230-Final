<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/EventRepository.php';
require_once __DIR__ . '/../../lib/Repositories/CategoryRepository.php';
require_once __DIR__ . '/../../lib/Repositories/OrganizerRepository.php';

Auth::requireAdmin();

$eventRepo     = new EventRepository();
$categoryRepo  = new CategoryRepository();
$organizerRepo = new OrganizerRepository();

$categories = $categoryRepo->getAll();
$organizers = $organizerRepo->getAll();

$errors = [];
$data   = [
    'title'        => '',
    'date'         => '',
    'location'     => '',
    'description'  => '',
    'category_id'  => '',
    'organizer_id' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['title']        = trim($_POST['title'] ?? '');
    $data['date']         = trim($_POST['date'] ?? '');
    $data['location']     = trim($_POST['location'] ?? '');
    $data['description']  = trim($_POST['description'] ?? '');
    $data['category_id']  = (int)($_POST['category_id'] ?? 0);
    $data['organizer_id'] = (int)($_POST['organizer_id'] ?? 0);

    if ($data['title'] === '') {
        $errors[] = "Title is required.";
    }
    if ($data['date'] === '') {
        $errors[] = "Date is required.";
    }
    if ($data['location'] === '') {
        $errors[] = "Location is required.";
    }
    if ($data['category_id'] <= 0) {
        $errors[] = "Please choose a category.";
    }
    if ($data['organizer_id'] <= 0) {
        $errors[] = "Please choose an organizer.";
    }

    if (empty($errors)) {
        $eventRepo->create([
            'title'        => $data['title'],
            'date'         => $data['date'],
            'location'     => $data['location'],
            'description'  => $data['description'],
            'category_id'  => $data['category_id'],
            'organizer_id' => $data['organizer_id'],
            'admin_id'     => null,
            'user_id'      => Auth::userId() // admin becomes owner
        ]);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Event created successfully.'
        ];

        header("Location: " . BASE_URL . "admin/events/index.php");
        exit();
    }
}

$pageTitle = "Admin – Create Event";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Create Event</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3">
    <div class="col-12">
        <label for="title" class="form-label">Title</label>
        <input type="text" id="title" name="title" class="form-control"
               value="<?= e($data['title']) ?>" required>
    </div>

    <div class="col-md-4">
        <label for="date" class="form-label">Date</label>
        <input type="date" id="date" name="date" class="form-control"
               value="<?= e($data['date']) ?>" required>
    </div>

    <div class="col-md-8">
        <label for="location" class="form-label">Location</label>
        <input type="text" id="location" name="location" class="form-control"
               value="<?= e($data['location']) ?>" required>
    </div>

    <div class="col-md-6">
        <label for="category_id" class="form-label">Category</label>
        <select id="category_id" name="category_id" class="form-select" required>
            <option value="">Select a category</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= (int)$cat['category_id'] ?>"
                    <?= $data['category_id'] == $cat['category_id'] ? 'selected' : '' ?>>
                    <?= e($cat['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="col-md-6">
        <label for="organizer_id" class="form-label">Organizer</label>
        <select id="organizer_id" name="organizer_id" class="form-select" required>
            <option value="">Select an organizer</option>
            <?php foreach ($organizers as $org): ?>
                <option value="<?= (int)$org['organizer_id'] ?>"
                    <?= $data['organizer_id'] == $org['organizer_id'] ? 'selected' : '' ?>>
                    <?= e($org['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="col-12">
        <label for="description" class="form-label">Description</label>
        <textarea id="description" name="description" rows="5"
                  class="form-control"><?= e($data['description']) ?></textarea>
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Save Event</button>
        <a href="<?= BASE_URL ?>admin/events/index.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
