<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/EventRepository.php';

Auth::requireAdmin();

$eventRepo = new EventRepository();

$id    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$event = $id > 0 ? $eventRepo->getById($id) : null;

if (!$event) {
    http_response_code(404);
    die("Event not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        $eventRepo->delete($id);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Event deleted.'
        ];
    }

    header("Location: " . BASE_URL . "admin/events/index.php");
    exit();
}

$pageTitle = "Admin – Delete Event";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4 text-danger">Delete Event</h1>

<p>Are you sure you want to delete the event <strong><?= e($event['title']) ?></strong> scheduled for <?= e($event['date']) ?>?</p>

<form method="post">
    <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes, delete it</button>
    <a href="<?= BASE_URL ?>admin/events/index.php" class="btn btn-secondary">Cancel</a>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
