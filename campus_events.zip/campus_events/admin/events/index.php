<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/EventRepository.php';

Auth::requireAdmin();

$eventRepo = new EventRepository();
$events    = $eventRepo->getAll();

$pageTitle = "Admin – Events";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Manage Events</h1>

<p class="mb-3">
    <a href="<?= BASE_URL ?>admin/events/create.php" class="btn btn-primary btn-sm">Create New Event</a>
</p>

<?php if (empty($events)): ?>
    <p>No events found.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
            <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Location</th>
                <th>Category</th>
                <th>Organizer</th>
                <th>Owner</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($events as $event): ?>
                <tr>
                    <td><?= e($event['title']) ?></td>
                    <td><?= e($event['date']) ?></td>
                    <td><?= e($event['location']) ?></td>
                    <td><?= e($event['category_name']) ?></td>
                    <td><?= e($event['organizer_name']) ?></td>
                    <td><?= e($event['owner_name']) ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>admin/events/edit.php?id=<?= (int)$event['event_id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <a href="<?= BASE_URL ?>admin/events/delete.php?id=<?= (int)$event['event_id'] ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
