<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/CategoryRepository.php';

Auth::requireAdmin();

$categoryRepo = new CategoryRepository();
$errors       = [];
$data         = [
    'name'        => '',
    'description' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['name']        = trim($_POST['name'] ?? '');
    $data['description'] = trim($_POST['description'] ?? '');

    if ($data['name'] === '') {
        $errors[] = "Name is required.";
    }

    if (empty($errors)) {
        $categoryRepo->create($data);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Category created successfully.'
        ];

        header("Location: " . BASE_URL . "admin/categories/index.php");
        exit();
    }
}

$pageTitle = "Admin – Create Category";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Create Category</h1>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
                <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" class="row g-3">
    <div class="col-12">
        <label for="name" class="form-label">Name</label>
        <input type="text" id="name" name="name" class="form-control"
               value="<?= e($data['name']) ?>" required>
    </div>

    <div class="col-12">
        <label for="description" class="form-label">Description</label>
        <textarea id="description" name="description" rows="4"
                  class="form-control"><?= e($data['description']) ?></textarea>
    </div>

    <div class="col-12">
        <button type="submit" class="btn btn-primary">Save Category</button>
        <a href="<?= BASE_URL ?>admin/categories/index.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
