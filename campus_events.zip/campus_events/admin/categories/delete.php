<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/CategoryRepository.php';

Auth::requireAdmin();

$categoryRepo = new CategoryRepository();

$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$cat = $id > 0 ? $categoryRepo->getById($id) : null;

if (!$cat) {
    http_response_code(404);
    die("Category not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['confirm'] === 'yes') {
        $categoryRepo->delete($id);

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => 'Category deleted.'
        ];
    }

    header("Location: " . BASE_URL . "admin/categories/index.php");
    exit();
}

$pageTitle = "Admin – Delete Category";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4 text-danger">Delete Category</h1>

<p>Are you sure you want to delete the category <strong><?= e($cat['name']) ?></strong>?</p>

<form method="post">
    <button type="submit" name="confirm" value="yes" class="btn btn-danger">Yes, delete it</button>
    <a href="<?= BASE_URL ?>admin/categories/index.php" class="btn btn-secondary">Cancel</a>
</form>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
