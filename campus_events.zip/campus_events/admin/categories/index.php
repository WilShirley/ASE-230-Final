<?php
require_once __DIR__ . '/../../lib/config.php';
require_once __DIR__ . '/../../lib/Auth.php';
require_once __DIR__ . '/../../lib/helpers.php';
require_once __DIR__ . '/../../lib/Repositories/CategoryRepository.php';

Auth::requireAdmin();

$categoryRepo = new CategoryRepository();
$categories   = $categoryRepo->getAll();

$pageTitle = "Admin – Categories";
require_once __DIR__ . '/../../partials/header.php';
?>

<h1 class="mb-4">Manage Categories</h1>

<p class="mb-3">
    <a href="<?= BASE_URL ?>admin/categories/create.php" class="btn btn-primary btn-sm">Create New Category</a>
</p>

<?php if (empty($categories)): ?>
    <p>No categories found.</p>
<?php else: ?>
    <table class="table table-striped align-middle">
        <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th style="width: 160px;">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($categories as $cat): ?>
            <tr>
                <td><?= e($cat['name']) ?></td>
                <td><?= e($cat['description']) ?></td>
                <td>
                    <a href="<?= BASE_URL ?>admin/categories/edit.php?id=<?= (int)$cat['category_id'] ?>"
                       class="btn btn-sm btn-outline-secondary">Edit</a>
                    <a href="<?= BASE_URL ?>admin/categories/delete.php?id=<?= (int)$cat['category_id'] ?>"
                       class="btn btn-sm btn-outline-danger">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/../../partials/footer.php'; ?>
